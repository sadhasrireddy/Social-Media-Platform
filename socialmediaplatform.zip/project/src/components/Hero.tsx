import React from 'react';
import { ArrowDown, Github, Linkedin, Mail } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-800"></div>
      <div className="absolute inset-0 bg-black/20"></div>
      
      {/* Animated Background Shapes */}
      <div className="absolute top-20 left-20 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>

      <div className="relative z-10 text-center text-white px-6 max-w-4xl mx-auto">
        <div className="mb-8 animate-fade-in">
          <div className="w-32 h-32 mx-auto mb-8 rounded-full bg-gradient-to-br from-white/20 to-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-2xl font-bold">
              JD
            </div>
          </div>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-slide-up">
          John <span className="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">Developer</span>
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 text-blue-100 animate-slide-up delay-200">
          Full-Stack Developer & UI/UX Designer
        </p>
        
        <p className="text-lg mb-12 text-blue-200 max-w-2xl mx-auto animate-slide-up delay-300">
          Crafting beautiful, functional web experiences with modern technologies. 
          Passionate about clean code, user experience, and innovative solutions.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12 animate-slide-up delay-400">
          <a
            href="#projects"
            className="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-blue-50 transition-all duration-300 hover:scale-105 shadow-lg"
          >
            View My Work
          </a>
          <a
            href="#contact"
            className="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-all duration-300 hover:scale-105"
          >
            Get In Touch
          </a>
        </div>

        <div className="flex justify-center space-x-6 mb-12 animate-slide-up delay-500">
          <a
            href="https://github.com"
            className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 hover:scale-110"
          >
            <Github size={20} />
          </a>
          <a
            href="https://linkedin.com"
            className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 hover:scale-110"
          >
            <Linkedin size={20} />
          </a>
          <a
            href="mailto:john@example.com"
            className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 hover:scale-110"
          >
            <Mail size={20} />
          </a>
        </div>

        <div className="animate-bounce">
          <a href="#about" className="inline-block">
            <ArrowDown size={24} className="text-white/70 hover:text-white transition-colors duration-300" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;