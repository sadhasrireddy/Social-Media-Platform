import React from 'react';
import { Heart, MessageCircle, UserPlus, Bell } from 'lucide-react';
import { formatDistanceToNow } from '../utils/dateUtils';

interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow';
  user: {
    username: string;
    avatar: string;
  };
  content?: string;
  created_at: string;
  read: boolean;
}

const NotificationsPage: React.FC = () => {
  const notifications: Notification[] = [
    {
      id: '1',
      type: 'like',
      user: {
        username: 'sarahsmith',
        avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150'
      },
      created_at: '2025-01-15T14:30:00Z',
      read: false
    },
    {
      id: '2',
      type: 'comment',
      user: {
        username: 'mikejohnson',
        avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150'
      },
      content: 'Great work on this project!',
      created_at: '2025-01-15T12:15:00Z',
      read: false
    },
    {
      id: '3',
      type: 'follow',
      user: {
        username: 'alexchen',
        avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150'
      },
      created_at: '2025-01-15T10:45:00Z',
      read: true
    },
    {
      id: '4',
      type: 'like',
      user: {
        username: 'emilydavis',
        avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150'
      },
      created_at: '2025-01-14T18:20:00Z',
      read: true
    }
  ];

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like':
        return <Heart size={16} className="text-red-500" />;
      case 'comment':
        return <MessageCircle size={16} className="text-blue-500" />;
      case 'follow':
        return <UserPlus size={16} className="text-green-500" />;
      default:
        return <Bell size={16} className="text-gray-500" />;
    }
  };

  const getNotificationText = (notification: Notification) => {
    switch (notification.type) {
      case 'like':
        return 'liked your post';
      case 'comment':
        return 'commented on your post';
      case 'follow':
        return 'started following you';
      default:
        return 'sent you a notification';
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h1 className="text-2xl font-bold text-gray-800">Notifications</h1>
        </div>
        
        <div className="divide-y divide-gray-100">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-6 hover:bg-gray-50 transition-colors duration-200 cursor-pointer ${
                !notification.read ? 'bg-blue-50' : ''
              }`}
            >
              <div className="flex items-start space-x-4">
                <div className="relative">
                  <img
                    src={notification.user.avatar}
                    alt={notification.user.username}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-sm">
                    {getNotificationIcon(notification.type)}
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <p className="text-gray-800">
                      <span className="font-semibold">{notification.user.username}</span>
                      {' '}
                      <span className="text-gray-600">{getNotificationText(notification)}</span>
                    </p>
                    {!notification.read && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    )}
                  </div>
                  
                  {notification.content && (
                    <p className="text-gray-600 mt-1 text-sm">"{notification.content}"</p>
                  )}
                  
                  <p className="text-sm text-gray-500 mt-2">
                    {formatDistanceToNow(notification.created_at)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {notifications.length === 0 && (
          <div className="p-12 text-center">
            <Bell size={48} className="mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-semibold text-gray-800 mb-2">No notifications yet</h3>
            <p className="text-gray-600">When someone interacts with your posts, you'll see it here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationsPage;