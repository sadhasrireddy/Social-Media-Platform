import React, { useState } from 'react';
import { Search, Users, Hash } from 'lucide-react';
import { mockUsers } from '../data/mockData';
import UserProfile from './UserProfile';

const SearchPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'users' | 'posts'>('users');

  const filteredUsers = mockUsers.filter(user =>
    user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.bio?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const trendingTopics = [
    { tag: 'webdevelopment', posts: 1234 },
    { tag: 'react', posts: 892 },
    { tag: 'javascript', posts: 756 },
    { tag: 'design', posts: 543 },
    { tag: 'startup', posts: 321 }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      {/* Search Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for people, posts, or topics..."
            className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-full focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
          />
        </div>
        
        <div className="flex space-x-4">
          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-full font-medium transition-all duration-200 ${
              activeTab === 'users'
                ? 'bg-blue-100 text-blue-600'
                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
            }`}
          >
            <Users size={18} />
            <span>People</span>
          </button>
          <button
            onClick={() => setActiveTab('posts')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-full font-medium transition-all duration-200 ${
              activeTab === 'posts'
                ? 'bg-blue-100 text-blue-600'
                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
            }`}
          >
            <Hash size={18} />
            <span>Posts</span>
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2">
          {activeTab === 'users' && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold text-gray-800 mb-4">
                {searchQuery ? `Search results for "${searchQuery}"` : 'Suggested People'}
              </h2>
              {filteredUsers.map((user) => (
                <UserProfile
                  key={user.id}
                  user={user}
                  isCurrentUser={user.id === '1'}
                  isFollowing={Math.random() > 0.5}
                  onFollow={(userId) => console.log('Follow user:', userId)}
                />
              ))}
            </div>
          )}
          
          {activeTab === 'posts' && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
              <Hash size={48} className="mx-auto text-gray-300 mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">No posts found</h3>
              <p className="text-gray-600">Try searching for different keywords or check out trending topics.</p>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Trending Topics */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Trending Topics</h3>
            <div className="space-y-3">
              {trendingTopics.map((topic, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors duration-200"
                >
                  <div>
                    <p className="font-semibold text-gray-800">#{topic.tag}</p>
                    <p className="text-sm text-gray-600">{topic.posts.toLocaleString()} posts</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Suggested Users */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Who to Follow</h3>
            <div className="space-y-4">
              {mockUsers.slice(1, 3).map((user) => (
                <div key={user.id} className="flex items-center space-x-3">
                  <img
                    src={user.avatar}
                    alt={user.username}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <p className="font-semibold text-gray-800">{user.username}</p>
                    <p className="text-sm text-gray-600">{user.followers_count.toLocaleString()} followers</p>
                  </div>
                  <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded-full hover:bg-blue-700 transition-colors duration-200">
                    Follow
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchPage;