import React, { useState } from 'react';
import { Image, Smile, MapPin, X } from 'lucide-react';
import { currentUser } from '../data/mockData';

interface CreatePostProps {
  onCreatePost: (content: string, imageUrl?: string) => void;
}

const CreatePost: React.FC<CreatePostProps> = ({ onCreatePost }) => {
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [showImageInput, setShowImageInput] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (content.trim()) {
      onCreatePost(content, imageUrl || undefined);
      setContent('');
      setImageUrl('');
      setShowImageInput(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
      <div className="flex items-start space-x-4">
        <img
          src={currentUser.avatar}
          alt={currentUser.username}
          className="w-12 h-12 rounded-full object-cover"
        />
        
        <div className="flex-1">
          <form onSubmit={handleSubmit} className="space-y-4">
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What's on your mind?"
              className="w-full resize-none border-none outline-none text-lg placeholder-gray-500 min-h-[100px]"
              maxLength={500}
            />
            
            {showImageInput && (
              <div className="relative">
                <input
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="Enter image URL..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={() => {
                    setShowImageInput(false);
                    setImageUrl('');
                  }}
                  className="absolute right-2 top-2 text-gray-400 hover:text-gray-600"
                >
                  <X size={16} />
                </button>
              </div>
            )}
            
            {imageUrl && (
              <div className="relative">
                <img
                  src={imageUrl}
                  alt="Preview"
                  className="w-full max-h-64 object-cover rounded-lg"
                  onError={() => setImageUrl('')}
                />
              </div>
            )}
            
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div className="flex items-center space-x-4">
                <button
                  type="button"
                  onClick={() => setShowImageInput(!showImageInput)}
                  className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors duration-200"
                >
                  <Image size={20} />
                  <span className="text-sm font-medium">Photo</span>
                </button>
                
                <button
                  type="button"
                  className="flex items-center space-x-2 text-gray-600 hover:text-yellow-600 transition-colors duration-200"
                >
                  <Smile size={20} />
                  <span className="text-sm font-medium">Feeling</span>
                </button>
                
                <button
                  type="button"
                  className="flex items-center space-x-2 text-gray-600 hover:text-green-600 transition-colors duration-200"
                >
                  <MapPin size={20} />
                  <span className="text-sm font-medium">Location</span>
                </button>
              </div>
              
              <button
                type="submit"
                disabled={!content.trim()}
                className={`px-6 py-2 rounded-full font-medium transition-all duration-200 ${
                  content.trim()
                    ? 'bg-blue-600 text-white hover:bg-blue-700 hover:scale-105'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                Post
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreatePost;