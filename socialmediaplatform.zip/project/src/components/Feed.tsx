import React, { useState } from 'react';
import PostCard from './PostCard';
import CreatePost from './CreatePost';
import { Post } from '../types';
import { mockPosts, currentUser } from '../data/mockData';
import { v4 as uuidv4 } from 'uuid';

const Feed: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>(mockPosts);

  const handleLike = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { 
            ...post, 
            is_liked: !post.is_liked,
            likes_count: post.is_liked ? post.likes_count - 1 : post.likes_count + 1
          }
        : post
    ));
  };

  const handleComment = (postId: string) => {
    // In a real app, this would open a comment modal or navigate to post details
    console.log('Comment on post:', postId);
  };

  const handleCreatePost = (content: string, imageUrl?: string) => {
    const newPost: Post = {
      id: uuidv4(),
      user_id: currentUser.id,
      content,
      image_url: imageUrl,
      likes_count: 0,
      comments_count: 0,
      created_at: new Date().toISOString(),
      user: currentUser,
      is_liked: false
    };
    
    setPosts([newPost, ...posts]);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <CreatePost onCreatePost={handleCreatePost} />
      
      <div className="space-y-6">
        {posts.map((post) => (
          <PostCard
            key={post.id}
            post={post}
            onLike={handleLike}
            onComment={handleComment}
          />
        ))}
      </div>
    </div>
  );
};

export default Feed;