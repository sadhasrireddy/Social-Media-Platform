import React, { useState } from 'react';
import { User } from '../types';
import { UserPlus, UserCheck, Settings } from 'lucide-react';

interface UserProfileProps {
  user: User;
  isCurrentUser?: boolean;
  isFollowing?: boolean;
  onFollow?: (userId: string) => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ 
  user, 
  isCurrentUser = false, 
  isFollowing = false, 
  onFollow 
}) => {
  const [following, setFollowing] = useState(isFollowing);

  const handleFollow = () => {
    if (onFollow) {
      onFollow(user.id);
      setFollowing(!following);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Cover Image */}
      <div className="h-32 bg-gradient-to-r from-blue-500 to-purple-600"></div>
      
      {/* Profile Info */}
      <div className="px-6 pb-6">
        <div className="flex items-end justify-between -mt-16 mb-4">
          <img
            src={user.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150'}
            alt={user.username}
            className="w-24 h-24 rounded-full border-4 border-white object-cover shadow-lg"
          />
          
          {!isCurrentUser && (
            <button
              onClick={handleFollow}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full font-medium transition-all duration-200 hover:scale-105 ${
                following
                  ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {following ? <UserCheck size={16} /> : <UserPlus size={16} />}
              <span>{following ? 'Following' : 'Follow'}</span>
            </button>
          )}
          
          {isCurrentUser && (
            <button className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-full font-medium hover:bg-gray-200 transition-colors duration-200">
              <Settings size={16} />
              <span>Edit Profile</span>
            </button>
          )}
        </div>

        <div className="space-y-3">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{user.username}</h2>
            <p className="text-gray-600">{user.email}</p>
          </div>
          
          {user.bio && (
            <p className="text-gray-700 leading-relaxed">{user.bio}</p>
          )}
          
          <div className="flex space-x-6 pt-2">
            <div className="text-center">
              <p className="text-xl font-bold text-gray-800">{user.followers_count.toLocaleString()}</p>
              <p className="text-sm text-gray-600">Followers</p>
            </div>
            <div className="text-center">
              <p className="text-xl font-bold text-gray-800">{user.following_count.toLocaleString()}</p>
              <p className="text-sm text-gray-600">Following</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;