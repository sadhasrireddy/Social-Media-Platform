import { User, Post, Comment } from '../types';

export const mockUsers: User[] = [
  {
    id: '1',
    username: 'johndoe',
    email: 'john@example.com',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Full-stack developer passionate about creating amazing user experiences.',
    followers_count: 1250,
    following_count: 890,
    created_at: '2024-01-15T10:00:00Z'
  },
  {
    id: '2',
    username: 'sarahsmith',
    email: 'sarah@example.com',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'UI/UX Designer crafting beautiful digital experiences.',
    followers_count: 2100,
    following_count: 650,
    created_at: '2024-01-10T08:30:00Z'
  },
  {
    id: '3',
    username: 'mikejohnson',
    email: 'mike@example.com',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Tech entrepreneur and startup enthusiast.',
    followers_count: 3400,
    following_count: 1200,
    created_at: '2024-01-05T14:20:00Z'
  }
];

export const mockPosts: Post[] = [
  {
    id: '1',
    user_id: '1',
    content: 'Just finished building an amazing React application! The component architecture is so clean and maintainable. Love how modern web development has evolved. 🚀',
    image_url: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=600',
    likes_count: 42,
    comments_count: 8,
    created_at: '2025-01-15T14:30:00Z',
    user: mockUsers[0],
    is_liked: false
  },
  {
    id: '2',
    user_id: '2',
    content: 'Working on some new design concepts for a mobile app. The user journey is everything! What do you think about this color palette?',
    image_url: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=600',
    likes_count: 67,
    comments_count: 12,
    created_at: '2025-01-15T12:15:00Z',
    user: mockUsers[1],
    is_liked: true
  },
  {
    id: '3',
    user_id: '3',
    content: 'Excited to announce our startup just raised Series A! Building the future of remote collaboration tools. The journey has been incredible so far.',
    likes_count: 156,
    comments_count: 23,
    created_at: '2025-01-15T09:45:00Z',
    user: mockUsers[2],
    is_liked: false
  },
  {
    id: '4',
    user_id: '1',
    content: 'Beautiful sunset from my home office today. Sometimes you need to step back and appreciate the simple things in life. 🌅',
    image_url: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=600',
    likes_count: 89,
    comments_count: 15,
    created_at: '2025-01-14T18:20:00Z',
    user: mockUsers[0],
    is_liked: true
  }
];

export const mockComments: Comment[] = [
  {
    id: '1',
    post_id: '1',
    user_id: '2',
    content: 'This looks amazing! Would love to see the code structure.',
    created_at: '2025-01-15T14:45:00Z',
    user: mockUsers[1]
  },
  {
    id: '2',
    post_id: '1',
    user_id: '3',
    content: 'React is definitely the way to go for modern apps!',
    created_at: '2025-01-15T15:00:00Z',
    user: mockUsers[2]
  },
  {
    id: '3',
    post_id: '2',
    user_id: '1',
    content: 'Love the color scheme! Very modern and clean.',
    created_at: '2025-01-15T12:30:00Z',
    user: mockUsers[0]
  }
];

export const currentUser = mockUsers[0];