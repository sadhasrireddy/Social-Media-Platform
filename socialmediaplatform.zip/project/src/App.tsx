import React, { useState } from 'react';
import Layout from './components/Layout';
import Feed from './components/Feed';
import SearchPage from './components/SearchPage';
import NotificationsPage from './components/NotificationsPage';
import ProfilePage from './components/ProfilePage';
import CreatePost from './components/CreatePost';

function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <Feed />;
      case 'search':
        return <SearchPage />;
      case 'create':
        return (
          <div className="max-w-2xl mx-auto">
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-gray-800 mb-2">Create New Post</h1>
              <p className="text-gray-600">Share what's on your mind with your followers.</p>
            </div>
            <CreatePost onCreatePost={(content, imageUrl) => {
              console.log('New post created:', { content, imageUrl });
              setActiveTab('home');
            }} />
          </div>
        );
      case 'notifications':
        return <NotificationsPage />;
      case 'profile':
        return <ProfilePage />;
      default:
        return <Feed />;
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </Layout>
  );
}

export default App;